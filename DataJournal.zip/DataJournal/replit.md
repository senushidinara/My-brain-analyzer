# Overview

This is an EEG Journal Analyzer application that combines artificial intelligence-powered brainwave analysis with real-time journaling capabilities. The system analyzes user journal entries using OpenAI's GPT-4o model to generate realistic EEG brainwave data and provide mood insights. The application features a modern React frontend with real-time brainwave visualization using Chart.js, integrated with an Express.js backend that handles AI analysis, data storage, and external service integrations.

## 🚀 Deployment Status

**Date**: August 7, 2025  
**Status**: Ready for free deployment on Render.com  
**Configuration**: render.yaml created for seamless deployment

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

**Framework**: React 18 with TypeScript and Vite for fast development builds
- **UI Library**: shadcn/ui components built on Radix UI primitives for accessible, customizable components
- **Styling**: Tailwind CSS with CSS custom properties for theming, featuring a space/cyberpunk aesthetic with glassmorphism effects
- **State Management**: TanStack React Query for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Charts**: Chart.js for real-time brainwave data visualization

**Component Structure**:
- `BrainwaveDisplay`: Real-time EEG data visualization with animated charts
- `JournalInput`: Text input with live word counting and analysis triggering
- `MoodAnalysis`: AI-generated mood insights display with confidence scoring
- `StatsPanel`: Data export functionality and historical entry management

## Backend Architecture

**Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints for journal analysis, data retrieval, and export
- **Validation**: Zod schemas for request/response validation and type safety
- **Error Handling**: Centralized error handling middleware with structured error responses

**Key Services**:
- **OpenAI Integration**: GPT-4o model for mood analysis and realistic EEG data generation
- **Notion Integration**: Automatic journal entry synchronization to Notion databases
- **Email Notifications**: Nodemailer with Gmail for daily reminder scheduling using cron jobs
- **CSV Export**: On-demand data export functionality for user analytics

## Data Storage Solutions

**Primary Storage**: In-memory storage using Map data structures for development/demo purposes
- Journal entries with EEG data, timestamps, and mood analysis
- User management with basic authentication structure
- Statistical calculations for brainwave pattern analysis

**Database Schema**: Drizzle ORM with PostgreSQL schema definitions ready for production deployment
- **Tables**: `journal_entries` and `users` with proper relationships and constraints
- **Migration Support**: Drizzle Kit configuration for schema migrations
- **Environment**: Neon Database serverless PostgreSQL for production scaling

## External Dependencies

**AI Services**:
- **OpenAI API**: GPT-4o model integration for mood analysis and EEG data generation
- **Usage**: Analyzes journal text to produce psychological insights and realistic brainwave patterns (Delta, Theta, Alpha, Beta, Gamma frequencies)

**Database Services**:
- **Neon Database**: Serverless PostgreSQL for production data persistence
- **Connection**: Environment-based configuration with connection pooling

**Productivity Integrations**:
- **Notion API**: Automatic journal entry synchronization to user's Notion workspace
- **Database Management**: Dynamic database creation and entry insertion with structured properties

**Communication Services**:
- **Gmail SMTP**: Automated daily reminder emails with HTML formatting
- **Scheduling**: Cron-based daily reminders (8 AM) with entry statistics

**Development Tools**:
- **Replit Integration**: Cartographer plugin for development environment integration
- **Vite Plugins**: Runtime error overlay and development banner for enhanced debugging
- **TypeScript**: Strict type checking with path mapping for clean imports

**UI Component Libraries**:
- **Radix UI**: Comprehensive set of accessible, unstyled components
- **Lucide React**: Icon library for consistent iconography
- **Class Variance Authority**: Type-safe component variant management
- **Date-fns**: Date manipulation and formatting utilities

# Free Deployment Guide

## Render.com Deployment (100% FREE)

### Prerequisites
- GitHub account
- Render.com account (free)
- Environment variables from Replit Secrets

### Step-by-Step Instructions

1. **Push to GitHub**:
   - Create a new GitHub repository
   - Copy all files from Replit to your repository
   - Push code: `git add .`, `git commit -m "Deploy EEG Journal"`, `git push`

2. **Deploy on Render**:
   - Go to [render.com](https://render.com)
   - Click "New" → "Web Service"
   - Connect your GitHub repository
   - Render will auto-detect the `render.yaml` configuration

3. **Set Environment Variables** in Render dashboard:
   ```
   OPENAI_API_KEY=sk-proj-XWj9CgD...
   NOTION_TOKEN=ntn_362102681021...
   NOTION_DATABASE_ID=24786e4cd7c680b6aefefc9c87674851
   EMAIL_USER=senushidinara2005@gmail.com (optional)
   EMAIL_PASS=your-gmail-app-password (optional)
   ```

4. **Deploy**:
   - Click "Create Web Service"
   - Wait 5-10 minutes for build and deployment
   - Your app will be live at `https://your-app-name.onrender.com`

### Cost: **100% FREE**
- Render free tier includes 750 hours/month
- App sleeps after 15 minutes of inactivity
- Wakes up automatically when visited (~30 seconds)
- Perfect for personal projects and demos

### Production Features Available:
- ✅ OpenAI GPT-4o mood analysis
- ✅ Real-time brainwave visualization
- ✅ Notion integration for data backup
- ✅ CSV data export
- ✅ Email reminders (if configured)
- ✅ Mobile-responsive interface
- ✅ HTTPS encryption
- ✅ Automatic deployments on git push

# Recent Changes

**August 7, 2025**:
- ✅ Application fully deployed and running on Replit
- ✅ OpenAI API integration configured and tested
- ✅ Notion database integration setup with user's database
- ✅ All TypeScript errors resolved
- ✅ Production-ready build configuration verified
- ✅ Render.com deployment configuration created
- ✅ Free hosting solution implemented
- ✅ Environment variables properly configured
- ✅ Email integration setup (optional)
- ✅ Real-time brainwave analysis working