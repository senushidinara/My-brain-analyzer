import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { analyzeMoodAndGenerateEEG } from "./openai";
import { notion, NOTION_DATABASE_ID, createDatabaseIfNotExists, findDatabaseByTitle, createJournalEntry as createNotionEntry } from "./notion";
import { analyzeJournalSchema } from "@shared/schema";
import * as cron from "node-cron";
import * as nodemailer from "nodemailer";

// Email transporter setup
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER || process.env.EMAIL_USER_ENV_VAR,
    pass: process.env.EMAIL_PASS || process.env.EMAIL_PASS_ENV_VAR
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize Notion database
  try {
    if (process.env.NOTION_TOKEN || process.env.NOTION_INTEGRATION_SECRET) {
      await createDatabaseIfNotExists("EEG Journal Entries", {
        Title: { title: {} },
        Text: { rich_text: {} },
        Timestamp: { date: {} },
        Delta: { number: {} },
        Theta: { number: {} },
        Alpha: { number: {} },
        Beta: { number: {} },
        Gamma: { number: {} },
        WordCount: { number: {} },
        MoodAnalysis: { rich_text: {} }
      });
      console.log('✅ Notion database initialized');
    }
  } catch (error: any) {
    console.log('⚠️ Notion not configured:', error?.message || 'Unknown error');
  }

  // Analyze journal entry
  app.post("/api/journal", async (req, res) => {
    try {
      const { text } = analyzeJournalSchema.parse(req.body);
      
      // Generate AI analysis and EEG data
      const analysis = await analyzeMoodAndGenerateEEG(text);
      
      // Store in memory
      const entry = await storage.createJournalEntry({
        text,
        eegData: analysis.eegData,
        moodAnalysis: analysis.moodAnalysis,
        wordCount: analysis.eegData.wordCount
      });

      // Save to Notion if configured
      try {
        if (process.env.NOTION_TOKEN || process.env.NOTION_INTEGRATION_SECRET) {
          await createNotionEntry({
            text,
            timestamp: entry.timestamp,
            delta: analysis.eegData.delta,
            theta: analysis.eegData.theta,
            alpha: analysis.eegData.alpha,
            beta: analysis.eegData.beta,
            gamma: analysis.eegData.gamma,
            wordCount: analysis.eegData.wordCount,
            moodAnalysis: analysis.moodAnalysis
          });
        }
      } catch (notionError: any) {
        console.log('⚠️ Notion save failed:', notionError?.message || 'Unknown error');
      }

      res.json({
        success: true,
        entry: {
          ...entry,
          eegData: analysis.eegData,
          moodAnalysis: analysis.moodAnalysis
        }
      });
    } catch (error: any) {
      console.error('Journal analysis error:', error);
      res.status(400).json({ 
        success: false, 
        error: error?.message || 'Analysis failed' 
      });
    }
  });

  // Get journal statistics
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getJournalStats();
      res.json(stats);
    } catch (error: any) {
      console.error('Stats error:', error);
      res.status(500).json({ error: 'Failed to get statistics' });
    }
  });

  // Get journal entries
  app.get("/api/entries", async (req, res) => {
    try {
      const entries = await storage.getAllJournalEntries();
      res.json(entries);
    } catch (error: any) {
      console.error('Entries error:', error);
      res.status(500).json({ error: 'Failed to get entries' });
    }
  });

  // Export CSV
  app.get("/api/export", async (req, res) => {
    try {
      const entries = await storage.getAllJournalEntries();
      
      const csvData = entries.map(entry => ({
        date: entry.timestamp.toISOString().split('T')[0],
        time: entry.timestamp.toTimeString().split(' ')[0],
        text: entry.text.replace(/"/g, '""'),
        delta: (entry.eegData as any).delta,
        theta: (entry.eegData as any).theta,
        alpha: (entry.eegData as any).alpha,
        beta: (entry.eegData as any).beta,
        gamma: (entry.eegData as any).gamma,
        wordCount: entry.wordCount,
        moodAnalysis: entry.moodAnalysis.replace(/"/g, '""')
      }));
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="eeg-journal-data.csv"');
      
      let csv = 'Date,Time,Text,Delta,Theta,Alpha,Beta,Gamma,WordCount,MoodAnalysis\n';
      csvData.forEach(row => {
        csv += `"${row.date}","${row.time}","${row.text}",${row.delta},${row.theta},${row.alpha},${row.beta},${row.gamma},${row.wordCount},"${row.moodAnalysis}"\n`;
      });
      
      res.send(csv);
    } catch (error: any) {
      console.error('Export error:', error);
      res.status(500).json({ error: 'Export failed' });
    }
  });

  // Health check
  app.get("/api/health", async (req, res) => {
    const entriesCount = await storage.getJournalEntriesCount();
    
    res.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      entries: entriesCount,
      services: {
        openai: process.env.OPENAI_API_KEY ? 'configured' : 'missing',
        notion: (process.env.NOTION_TOKEN || process.env.NOTION_INTEGRATION_SECRET) ? 'configured' : 'missing',
        email: process.env.EMAIL_USER ? 'configured' : 'missing'
      }
    });
  });

  // Daily reminder cron job (8 AM every day)
  if (process.env.EMAIL_USER && process.env.EMAIL_PASS) {
    cron.schedule('0 8 * * *', async () => {
      try {
        const entriesCount = await storage.getJournalEntriesCount();
        const reployUrl = process.env.REPL_URL || 'http://localhost:5000';
        
        const mailOptions = {
          from: process.env.EMAIL_USER,
          to: process.env.EMAIL_USER, // Send to same email for now
          subject: '🧠 Daily EEG Journal Reminder - Time to Analyze Your Mind!',
          html: `
            <h2>🧠 Your Daily Brainwave Check-in</h2>
            <p>Good morning! It's time to record your thoughts and analyze your mental patterns.</p>
            <p><strong>Today's Focus:</strong> How are you feeling? What's on your mind?</p>
            <p><a href="${reployUrl}" style="background:#5ce1e6;color:white;padding:10px 20px;text-decoration:none;border-radius:5px;">Open EEG Journal 🚀</a></p>
            <p><small>Total entries so far: ${entriesCount}</small></p>
          `
        };
        
        await transporter.sendMail(mailOptions);
        console.log('✅ Daily reminder sent successfully');
      } catch (error: any) {
        console.log('❌ Email reminder error:', error?.message || 'Unknown error');
      }
    });
    console.log('✅ Daily reminder cron job scheduled for 8:00 AM');
  }

  const httpServer = createServer(app);
  return httpServer;
}
