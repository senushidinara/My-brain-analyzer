import { type JournalEntry, type InsertJournalEntry, type User, type InsertUser } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createJournalEntry(entry: InsertJournalEntry): Promise<JournalEntry>;
  getAllJournalEntries(): Promise<JournalEntry[]>;
  getJournalEntriesCount(): Promise<number>;
  getJournalStats(): Promise<{
    totalEntries: number;
    analysisDate: string;
    delta: { mean: number; sd: number; min: number; max: number };
    theta: { mean: number; sd: number; min: number; max: number };
    alpha: { mean: number; sd: number; min: number; max: number };
    beta: { mean: number; sd: number; min: number; max: number };
    gamma: { mean: number; sd: number; min: number; max: number };
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private journalEntries: Map<string, JournalEntry>;

  constructor() {
    this.users = new Map();
    this.journalEntries = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createJournalEntry(insertEntry: InsertJournalEntry): Promise<JournalEntry> {
    const id = randomUUID();
    const entry: JournalEntry = {
      ...insertEntry,
      id,
      timestamp: new Date(),
    };
    this.journalEntries.set(id, entry);
    return entry;
  }

  async getAllJournalEntries(): Promise<JournalEntry[]> {
    return Array.from(this.journalEntries.values()).sort(
      (a, b) => b.timestamp.getTime() - a.timestamp.getTime()
    );
  }

  async getJournalEntriesCount(): Promise<number> {
    return this.journalEntries.size;
  }

  async getJournalStats(): Promise<{
    totalEntries: number;
    analysisDate: string;
    delta: { mean: number; sd: number; min: number; max: number };
    theta: { mean: number; sd: number; min: number; max: number };
    alpha: { mean: number; sd: number; min: number; max: number };
    beta: { mean: number; sd: number; min: number; max: number };
    gamma: { mean: number; sd: number; min: number; max: number };
  }> {
    const entries = Array.from(this.journalEntries.values());
    
    if (entries.length === 0) {
      return {
        totalEntries: 0,
        analysisDate: new Date().toISOString(),
        delta: { mean: 0, sd: 0, min: 0, max: 0 },
        theta: { mean: 0, sd: 0, min: 0, max: 0 },
        alpha: { mean: 0, sd: 0, min: 0, max: 0 },
        beta: { mean: 0, sd: 0, min: 0, max: 0 },
        gamma: { mean: 0, sd: 0, min: 0, max: 0 },
      };
    }

    const calculateStats = (values: number[]) => {
      const mean = Math.round(values.reduce((sum, val) => sum + val, 0) / values.length);
      const variance = values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / values.length;
      const sd = Math.round(Math.sqrt(variance));
      return {
        mean,
        sd,
        min: Math.min(...values),
        max: Math.max(...values),
      };
    };

    const deltaValues = entries.map(e => (e.eegData as any).delta);
    const thetaValues = entries.map(e => (e.eegData as any).theta);
    const alphaValues = entries.map(e => (e.eegData as any).alpha);
    const betaValues = entries.map(e => (e.eegData as any).beta);
    const gammaValues = entries.map(e => (e.eegData as any).gamma);

    return {
      totalEntries: entries.length,
      analysisDate: new Date().toISOString(),
      delta: calculateStats(deltaValues),
      theta: calculateStats(thetaValues),
      alpha: calculateStats(alphaValues),
      beta: calculateStats(betaValues),
      gamma: calculateStats(gammaValues),
    };
  }
}

export const storage = new MemStorage();
