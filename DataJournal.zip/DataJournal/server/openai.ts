import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface EEGData {
  delta: number;
  theta: number;
  alpha: number;
  beta: number;
  gamma: number;
  wordCount: number;
}

export async function analyzeMoodAndGenerateEEG(text: string): Promise<{
  moodAnalysis: string;
  eegData: EEGData;
}> {
  try {
    const wordCount = text.trim().split(/\s+/).filter(word => word.length > 0).length;
    
    // Generate mood analysis
    const moodResponse = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert psychologist and neuroscientist. Analyze the emotional and mental state of the journal entry and provide insights about creativity, stress levels, emotional processing, and mental well-being. Be supportive and constructive."
        },
        {
          role: "user",
          content: `Analyze this journal entry for mood and mental state: "${text}"`
        }
      ],
      max_tokens: 500,
    });

    // Generate realistic EEG data based on text analysis
    const eegResponse = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are an EEG analysis expert. Based on the journal text content, generate realistic brainwave values (0-100) that reflect the mental state. Consider:
          - Delta (0.5-4 Hz): Deep sleep, unconscious processing - higher when relaxed/tired
          - Theta (4-8 Hz): Creativity, meditation, deep thought - higher when creative/reflective  
          - Alpha (8-13 Hz): Relaxed awareness, calm focus - higher when calm/focused
          - Beta (13-30 Hz): Active thinking, alertness, anxiety - higher when active/stressed
          - Gamma (30-100 Hz): Insight, higher consciousness - higher when having insights
          
          Respond with JSON in this exact format: {"delta": number, "theta": number, "alpha": number, "beta": number, "gamma": number}`
        },
        {
          role: "user",
          content: `Generate EEG brainwave data for this journal entry: "${text}"`
        }
      ],
      response_format: { type: "json_object" },
    });

    const eegData = JSON.parse(eegResponse.choices[0].message.content || "{}");
    
    return {
      moodAnalysis: moodResponse.choices[0].message.content || "Unable to analyze mood at this time.",
      eegData: {
        delta: Math.max(0, Math.min(100, Math.round(eegData.delta || 20))),
        theta: Math.max(0, Math.min(100, Math.round(eegData.theta || 30))),
        alpha: Math.max(0, Math.min(100, Math.round(eegData.alpha || 40))),
        beta: Math.max(0, Math.min(100, Math.round(eegData.beta || 50))),
        gamma: Math.max(0, Math.min(100, Math.round(eegData.gamma || 25))),
        wordCount
      }
    };
  } catch (error) {
    console.error('OpenAI analysis error:', error);
    
    // Fallback EEG data based on text characteristics if API fails
    const wordCount = text.trim().split(/\s+/).filter(word => word.length > 0).length;
    const textLength = text.length;
    
    return {
      moodAnalysis: "AI analysis temporarily unavailable. Your journal entry has been recorded successfully.",
      eegData: {
        delta: Math.min(100, Math.max(10, Math.round((300 - textLength) / 5))),
        theta: Math.min(100, Math.max(15, Math.round(textLength / 10))),
        alpha: Math.min(100, Math.max(20, Math.round(wordCount * 2))),
        beta: Math.min(100, Math.max(25, Math.round(textLength / 8))),
        gamma: Math.min(100, Math.max(10, Math.round(wordCount * 1.5))),
        wordCount
      }
    };
  }
}
