import { Client } from "@notionhq/client";

// Initialize Notion client
export const notion = new Client({
    auth: process.env.NOTION_TOKEN || process.env.NOTION_INTEGRATION_SECRET!,
});

// Use database ID directly from environment
export const NOTION_DATABASE_ID = process.env.NOTION_DATABASE_ID!;
export const NOTION_PAGE_ID = process.env.NOTION_DATABASE_ID!; // For backward compatibility

/**
 * Gets the main database
 * @returns {Promise<any>} - Database object
 */
export async function getNotionDatabase() {
    try {
        const databaseInfo = await notion.databases.retrieve({
            database_id: NOTION_DATABASE_ID,
        });
        return databaseInfo;
    } catch (error) {
        console.error("Error retrieving database:", error);
        throw error;
    }
}

// Find get a Notion database with the matching title
export async function findDatabaseByTitle(title: string) {
    try {
        const database = await getNotionDatabase();
        return database;
    } catch (error) {
        console.error("Error finding database:", error);
        return null;
    }
}

// Create a new database if one with a matching title does not exist
export async function createDatabaseIfNotExists(title: string, properties: any) {
    try {
        const existingDb = await findDatabaseByTitle(title);
        if (existingDb) {
            return existingDb;
        }
        // For now, just return the existing database since we have a specific DB ID
        return await getNotionDatabase();
    } catch (error) {
        console.error("Error creating database:", error);
        return await getNotionDatabase();
    }
}


// Function to create a journal entry in Notion
export async function createJournalEntry(entryData: {
    text: string;
    timestamp: Date;
    delta: number;
    theta: number;
    alpha: number;
    beta: number;
    gamma: number;
    wordCount: number;
    moodAnalysis: string;
}) {
    try {
        const response = await notion.pages.create({
            parent: { database_id: NOTION_DATABASE_ID },
            properties: {
                Title: {
                    title: [{ text: { content: `Entry ${entryData.timestamp.toISOString().split('T')[0]}` } }]
                },
                Text: {
                    rich_text: [{ text: { content: entryData.text.substring(0, 2000) } }]
                },
                Timestamp: {
                    date: { start: entryData.timestamp.toISOString() }
                },
                Delta: { number: entryData.delta },
                Theta: { number: entryData.theta },
                Alpha: { number: entryData.alpha },
                Beta: { number: entryData.beta },
                Gamma: { number: entryData.gamma },
                WordCount: { number: entryData.wordCount },
                MoodAnalysis: {
                    rich_text: [{ text: { content: entryData.moodAnalysis.substring(0, 2000) } }]
                }
            }
        });
        return response;
    } catch (error) {
        console.error("Error creating journal entry in Notion:", error);
        throw new Error("Failed to create journal entry in Notion");
    }
}