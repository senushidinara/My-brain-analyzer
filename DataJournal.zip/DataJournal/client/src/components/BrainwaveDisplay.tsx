import { useEffect, useRef } from "react";
import { Chart, registerables } from "chart.js";

Chart.register(...registerables);

interface EEGData {
  delta: number;
  theta: number;
  alpha: number;
  beta: number;
  gamma: number;
  wordCount: number;
}

interface BrainwaveDisplayProps {
  eegData?: EEGData;
}

export function BrainwaveDisplay({ eegData }: BrainwaveDisplayProps) {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstanceRef = useRef<Chart | null>(null);

  useEffect(() => {
    if (chartRef.current) {
      const ctx = chartRef.current.getContext('2d');
      if (ctx) {
        // Destroy existing chart
        if (chartInstanceRef.current) {
          chartInstanceRef.current.destroy();
        }

        chartInstanceRef.current = new Chart(ctx, {
          type: 'line',
          data: {
            labels: Array.from({length: 60}, (_, i) => `${i}s`),
            datasets: [{
              label: 'Alpha',
              data: Array.from({length: 60}, () => Math.random() * 50),
              borderColor: '#9d4edd',
              tension: 0.4,
              fill: false
            }, {
              label: 'Beta', 
              data: Array.from({length: 60}, () => Math.random() * 40),
              borderColor: '#ff6b6b',
              tension: 0.4,
              fill: false
            }, {
              label: 'Theta',
              data: Array.from({length: 60}, () => Math.random() * 35),
              borderColor: '#5ce1e6',
              tension: 0.4,
              fill: false
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                labels: {
                  color: '#ffffff'
                }
              }
            },
            scales: {
              x: {
                grid: { color: 'rgba(255,255,255,0.1)' },
                ticks: { color: '#ffffff' }
              },
              y: {
                grid: { color: 'rgba(255,255,255,0.1)' },
                ticks: { color: '#ffffff' }
              }
            }
          }
        });

        // Update chart with new data every 2 seconds
        const interval = setInterval(() => {
          if (chartInstanceRef.current) {
            chartInstanceRef.current.data.datasets.forEach((dataset: any) => {
              dataset.data.shift();
              dataset.data.push(Math.random() * 50);
            });
            chartInstanceRef.current.update('none');
          }
        }, 2000);

        return () => clearInterval(interval);
      }
    }
  }, []);

  return (
    <div className="glassmorphism rounded-3xl p-8">
      <div className="flex items-center gap-3 mb-6">
        <i className="fas fa-wave-square text-cyber-cyan text-xl"></i>
        <h3 className="text-xl font-bold text-cyber-cyan">Live EEG Frequencies</h3>
        <div className="ml-auto flex gap-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span className="text-xs text-green-400">Recording</span>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-2 2xl:grid-cols-5 gap-4 mb-6">
        {/* Delta Wave */}
        <div className="bg-delta-gradient rounded-2xl p-4 text-center hover:scale-105 transition-all duration-300 wave-glow">
          <div className="text-xs font-medium mb-1 opacity-90">Delta</div>
          <div data-testid="delta-value" className="text-2xl font-bold mb-1">{eegData?.delta || 0}</div>
          <div className="text-xs opacity-75">Deep Sleep</div>
        </div>
        
        {/* Theta Wave */}
        <div className="bg-theta-gradient rounded-2xl p-4 text-center hover:scale-105 transition-all duration-300 wave-glow">
          <div className="text-xs font-medium mb-1 opacity-90">Theta</div>
          <div data-testid="theta-value" className="text-2xl font-bold mb-1">{eegData?.theta || 0}</div>
          <div className="text-xs opacity-75">Creativity</div>
        </div>
        
        {/* Alpha Wave */}
        <div className="bg-alpha-gradient rounded-2xl p-4 text-center hover:scale-105 transition-all duration-300 wave-glow">
          <div className="text-xs font-medium mb-1 opacity-90">Alpha</div>
          <div data-testid="alpha-value" className="text-2xl font-bold mb-1">{eegData?.alpha || 0}</div>
          <div className="text-xs opacity-75">Relaxation</div>
        </div>
        
        {/* Beta Wave */}
        <div className="bg-beta-gradient rounded-2xl p-4 text-center hover:scale-105 transition-all duration-300 wave-glow">
          <div className="text-xs font-medium mb-1 opacity-90">Beta</div>
          <div data-testid="beta-value" className="text-2xl font-bold mb-1">{eegData?.beta || 0}</div>
          <div className="text-xs opacity-75">Focus</div>
        </div>
        
        {/* Gamma Wave */}
        <div className="bg-gamma-gradient rounded-2xl p-4 text-center hover:scale-105 transition-all duration-300 wave-glow col-span-2 lg:col-span-1 xl:col-span-2 2xl:col-span-1">
          <div className="text-xs font-medium mb-1 opacity-90 text-black">Gamma</div>
          <div data-testid="gamma-value" className="text-2xl font-bold mb-1 text-black">{eegData?.gamma || 0}</div>
          <div className="text-xs opacity-75 text-black">Insight</div>
        </div>
      </div>

      <div className="bg-black/30 rounded-2xl p-4">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-semibold text-cyber-cyan">Real-time Waveform</h4>
          <div className="flex gap-2">
            <button className="text-xs px-3 py-1 bg-cyber-cyan/20 text-cyber-cyan rounded-lg hover:bg-cyber-cyan/30 transition-colors">
              1m
            </button>
            <button className="text-xs px-3 py-1 bg-gray-600/50 text-gray-300 rounded-lg hover:bg-gray-600 transition-colors">
              5m
            </button>
            <button className="text-xs px-3 py-1 bg-gray-600/50 text-gray-300 rounded-lg hover:bg-gray-600 transition-colors">
              15m
            </button>
          </div>
        </div>
        <div className="h-48 bg-gray-900/50 rounded-xl flex items-center justify-center">
          <canvas 
            ref={chartRef}
            data-testid="brainwave-chart" 
            className="w-full h-full"
          />
        </div>
      </div>
    </div>
  );
}
