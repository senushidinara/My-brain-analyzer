import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface JournalEntry {
  id: string;
  text: string;
  timestamp: string;
  eegData: {
    delta: number;
    theta: number;
    alpha: number;
    beta: number;
    gamma: number;
    wordCount: number;
  };
  moodAnalysis: string;
  wordCount: number;
}

interface JournalInputProps {
  onAnalysisComplete: (entry: JournalEntry) => void;
  onStatusChange: (status: string) => void;
}

export function JournalInput({ onAnalysisComplete, onStatusChange }: JournalInputProps) {
  const [text, setText] = useState("");
  const [wordCount, setWordCount] = useState(0);
  const queryClient = useQueryClient();

  const analyzeJournalMutation = useMutation({
    mutationFn: async (data: { text: string }) => {
      const response = await apiRequest("POST", "/api/journal", data);
      return response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        onAnalysisComplete(data.entry);
        onStatusChange("🟢 Analysis Complete");
        toast({
          title: "Analysis Complete",
          description: "Your brainwave patterns have been analyzed successfully.",
        });
        // Invalidate stats and entries to refresh data
        queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
        queryClient.invalidateQueries({ queryKey: ["/api/entries"] });
      }
    },
    onError: (error: Error) => {
      onStatusChange("🔴 Analysis Error");
      toast({
        title: "Analysis Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleTextChange = (value: string) => {
    setText(value);
    const words = value.trim().split(/\s+/).filter(word => word.length > 0);
    setWordCount(words.length);
  };

  const handleAnalyze = () => {
    if (!text.trim() || text.trim().length < 10) {
      toast({
        title: "Text too short",
        description: "Please write at least 10 characters for accurate analysis.",
        variant: "destructive",
      });
      return;
    }
    
    onStatusChange("🧠 Analyzing...");
    analyzeJournalMutation.mutate({ text });
  };

  const handleClear = () => {
    setText("");
    setWordCount(0);
  };

  return (
    <div className="glassmorphism rounded-3xl p-8">
      <div className="flex items-center gap-3 mb-6">
        <i className="fas fa-brain text-cyber-cyan text-xl"></i>
        <h3 className="text-xl font-bold text-cyber-cyan">Neural Journal Interface</h3>
        <div className="ml-auto">
          <span className="text-xs px-3 py-1 bg-green-500/20 text-green-400 rounded-full border border-green-500/30">
            Live Analysis
          </span>
        </div>
      </div>
      
      <Textarea 
        data-testid="journal-textarea"
        className="w-full h-40 bg-glass text-white border border-cyber-cyan/30 rounded-2xl p-6 text-lg resize-none focus:outline-none focus:border-cyber-cyan focus:ring-4 focus:ring-cyber-cyan/20 transition-all duration-300"
        placeholder="Express your deepest thoughts, emotions, reflections, dreams, and ideas. The AI will analyze your mental patterns and generate personalized brainwave data..."
        value={text}
        onChange={(e) => handleTextChange(e.target.value)}
      />
      
      <div className="text-right text-purple-300 text-sm mt-2">
        <span data-testid="word-count">{wordCount}</span> words • <span className="text-cyber-cyan">Ready for Analysis</span>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6">
        <Button 
          data-testid="button-analyze"
          onClick={handleAnalyze}
          disabled={analyzeJournalMutation.isPending}
          className="bg-cyber-gradient text-white px-6 py-4 rounded-xl font-semibold flex items-center justify-center gap-2 hover:scale-105 hover:shadow-xl hover:shadow-cyber-cyan/20 transition-all duration-300 h-auto"
        >
          <i className="fas fa-brain"></i>
          {analyzeJournalMutation.isPending ? "Analyzing..." : "Analyze Brainwaves"}
        </Button>
        
        <Button 
          data-testid="button-save"
          variant="outline"
          className="bg-purple-600/70 hover:bg-purple-600 text-white px-6 py-4 rounded-xl font-semibold flex items-center justify-center gap-2 hover:scale-105 transition-all duration-300 h-auto border-purple-600/50"
        >
          <i className="fab fa-notion"></i>
          Save to Notion
        </Button>
        
        <Button 
          data-testid="button-clear"
          onClick={handleClear}
          variant="outline"
          className="bg-red-500/70 hover:bg-red-500 text-white px-6 py-4 rounded-xl font-semibold flex items-center justify-center gap-2 hover:scale-105 transition-all duration-300 h-auto border-red-500/50"
        >
          <i className="fas fa-trash"></i>
          Clear
        </Button>
      </div>
      
      <div className="mt-6 p-4 bg-blue-500/10 rounded-xl border border-blue-500/30">
        <div className="flex items-center gap-2 text-blue-300">
          <i className="fas fa-info-circle"></i>
          <span className="text-sm">
            Analysis Status: <span data-testid="analysis-status" className="font-semibold">Ready</span>
          </span>
        </div>
      </div>
    </div>
  );
}
