interface JournalEntry {
  id: string;
  text: string;
  timestamp: string;
  eegData: {
    delta: number;
    theta: number;
    alpha: number;
    beta: number;
    gamma: number;
    wordCount: number;
  };
  moodAnalysis: string;
  wordCount: number;
}

interface MoodAnalysisProps {
  moodAnalysis?: string;
  entry?: JournalEntry | null;
}

export function MoodAnalysis({ moodAnalysis, entry }: MoodAnalysisProps) {
  const getConfidenceScore = () => {
    if (!entry) return 0;
    // Calculate confidence based on word count and analysis quality
    const wordCount = entry.wordCount;
    const hasAnalysis = moodAnalysis && moodAnalysis.length > 50;
    
    let confidence = Math.min(95, 60 + (wordCount * 0.5));
    if (!hasAnalysis) confidence = Math.max(30, confidence - 20);
    
    return Math.round(confidence);
  };

  const confidenceScore = getConfidenceScore();

  return (
    <div className="lg:col-span-2 glassmorphism rounded-3xl p-8">
      <div className="flex items-center gap-3 mb-6">
        <i className="fas fa-brain text-yellow-400 text-xl"></i>
        <h3 className="text-xl font-bold text-yellow-400">AI Mood Analysis</h3>
        <div className="ml-auto">
          <span className="text-xs px-3 py-1 bg-yellow-400/20 text-yellow-400 rounded-full border border-yellow-400/30">
            OpenAI GPT-4
          </span>
        </div>
      </div>
      
      <div className="space-y-4">
        <div className="bg-yellow-400/10 border-l-4 border-yellow-400 rounded-r-xl p-6">
          <h4 className="font-semibold text-yellow-400 mb-3">Current Mental State Analysis</h4>
          <p data-testid="mood-analysis-text" className="text-gray-300 leading-relaxed">
            {moodAnalysis || "Write in your journal and click 'Analyze Brainwaves' to see your personalized AI mood analysis appear here. The analysis will provide insights into your emotional state, creativity levels, and mental well-being patterns."}
          </p>
        </div>
        
        {entry && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-green-500/10 rounded-xl p-4 border border-green-500/30">
              <h5 className="font-semibold text-green-400 mb-2 flex items-center gap-2">
                <i className="fas fa-plus-circle"></i>
                Positive Indicators
              </h5>
              <ul className="text-sm text-gray-300 space-y-1">
                {entry.eegData.theta > 40 && <li>• High creativity patterns detected</li>}
                {entry.eegData.alpha > 35 && <li>• Strong relaxation signals</li>}
                {entry.wordCount > 50 && <li>• Detailed self-expression</li>}
                {entry.eegData.gamma > 30 && <li>• Insight generation active</li>}
              </ul>
            </div>
            
            <div className="bg-orange-500/10 rounded-xl p-4 border border-orange-500/30">
              <h5 className="font-semibold text-orange-400 mb-2 flex items-center gap-2">
                <i className="fas fa-exclamation-triangle"></i>
                Areas to Monitor
              </h5>
              <ul className="text-sm text-gray-300 space-y-1">
                {entry.eegData.beta > 60 && <li>• Elevated stress indicators</li>}
                {entry.eegData.delta > 50 && <li>• Low energy patterns</li>}
                {entry.wordCount < 20 && <li>• Brief entry - consider elaborating</li>}
                {entry.eegData.alpha < 20 && <li>• Consider relaxation techniques</li>}
              </ul>
            </div>
          </div>
        )}
      </div>
      
      {entry && (
        <div className="mt-6 p-4 bg-blue-500/10 rounded-xl border border-blue-500/30">
          <div className="flex items-center justify-between">
            <span className="text-blue-300">AI Confidence Score</span>
            <div className="flex items-center gap-2">
              <div className="w-32 h-2 bg-gray-700 rounded-full">
                <div 
                  className="h-2 bg-blue-400 rounded-full transition-all duration-500"
                  style={{ width: `${confidenceScore}%` }}
                ></div>
              </div>
              <span data-testid="confidence-score" className="text-blue-300 font-semibold">{confidenceScore}%</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
