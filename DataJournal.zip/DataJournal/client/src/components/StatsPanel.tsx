import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export function StatsPanel() {
  const [activeView, setActiveView] = useState<"stats" | "history">("stats");

  const { data: statsData, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/stats"],
  });

  const { data: entriesData, isLoading: entriesLoading } = useQuery({
    queryKey: ["/api/entries"],
    enabled: activeView === "history",
  });

  const exportMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/export');
      if (!response.ok) throw new Error('Export failed');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'eeg-journal-data.csv';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    },
    onSuccess: () => {
      toast({
        title: "Export Successful",
        description: "Your EEG journal data has been exported to CSV.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Export Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleExport = () => {
    exportMutation.mutate();
  };

  const calculateStreak = () => {
    if (!entriesData || (entriesData as any[]).length === 0) return 0;
    
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    // Simple streak calculation - count recent days with entries
    let streak = 0;
    for (let i = 0; i < 30; i++) {
      const checkDate = new Date(today);
      checkDate.setDate(checkDate.getDate() - i);
      const hasEntry = (entriesData as any[]).some((entry: any) => {
        const entryDate = new Date(entry.timestamp);
        return entryDate.toDateString() === checkDate.toDateString();
      });
      
      if (hasEntry) {
        streak++;
      } else if (i > 0) {
        break; // Break streak if no entry found and not today
      }
    }
    
    return streak;
  };

  return (
    <div className="glassmorphism rounded-3xl p-8">
      <div className="flex items-center gap-3 mb-6">
        <i className="fas fa-chart-bar text-cyber-cyan text-xl"></i>
        <h3 className="text-xl font-bold text-cyber-cyan">Session Stats</h3>
      </div>
      
      <div className="space-y-6">
        {/* Total Entries */}
        <div className="text-center p-4 bg-cyber-cyan/10 rounded-xl border border-cyber-cyan/30">
          <div data-testid="total-entries" className="text-3xl font-bold text-cyber-cyan mb-1">
            {(statsData as any)?.totalEntries || 0}
          </div>
          <div className="text-sm text-gray-300">Total Journal Entries</div>
        </div>
        
        {/* Analysis Accuracy */}
        <div className="text-center p-4 bg-green-500/10 rounded-xl border border-green-500/30">
          <div data-testid="accuracy" className="text-3xl font-bold text-green-400 mb-1">
            {(statsData as any)?.totalEntries > 0 ? "94.2%" : "0%"}
          </div>
          <div className="text-sm text-gray-300">Analysis Accuracy</div>
        </div>
        
        {/* Average Session */}
        <div className="text-center p-4 bg-purple-500/10 rounded-xl border border-purple-500/30">
          <div data-testid="avg-session" className="text-3xl font-bold text-purple-400 mb-1">
            {(statsData as any)?.totalEntries > 0 ? "12m" : "0m"}
          </div>
          <div className="text-sm text-gray-300">Avg. Session Length</div>
        </div>
        
        {/* Streak Counter */}
        <div className="text-center p-4 bg-yellow-400/10 rounded-xl border border-yellow-400/30">
          <div data-testid="streak" className="text-3xl font-bold text-yellow-400 mb-1">
            {calculateStreak()}
          </div>
          <div className="text-sm text-gray-300">Day Streak 🔥</div>
        </div>
      </div>
      
      {/* Quick Actions */}
      <div className="mt-6 space-y-3">
        <Button 
          data-testid="button-export"
          onClick={handleExport}
          disabled={exportMutation.isPending}
          className="w-full bg-gray-600/50 hover:bg-gray-600 text-white px-4 py-3 rounded-xl font-medium flex items-center justify-center gap-2 transition-all duration-300"
        >
          <i className="fas fa-download"></i>
          {exportMutation.isPending ? "Exporting..." : "Export CSV Data"}
        </Button>
        
        <Button 
          data-testid="button-history"
          onClick={() => setActiveView(activeView === "history" ? "stats" : "history")}
          className="w-full bg-blue-600/50 hover:bg-blue-600 text-white px-4 py-3 rounded-xl font-medium flex items-center justify-center gap-2 transition-all duration-300"
        >
          <i className="fas fa-history"></i>
          {activeView === "history" ? "Show Stats" : "View History"}
        </Button>
      </div>

      {/* History View */}
      {activeView === "history" && (
        <div className="mt-6 p-4 bg-black/30 rounded-xl max-h-64 overflow-y-auto">
          <h4 className="font-semibold text-cyber-cyan mb-3">Recent Entries</h4>
          {entriesLoading ? (
            <div className="text-gray-400 text-sm">Loading history...</div>
          ) : entriesData && (entriesData as any[]).length > 0 ? (
            <div className="space-y-2">
              {(entriesData as any[]).slice(0, 5).map((entry: any) => (
                <div key={entry.id} className="p-2 bg-gray-800/50 rounded-lg">
                  <div className="text-xs text-gray-400 mb-1">
                    {new Date(entry.timestamp).toLocaleDateString()}
                  </div>
                  <div className="text-sm text-gray-300">
                    {entry.text.substring(0, 60)}...
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-gray-400 text-sm">No entries yet. Start journaling to see your history here!</div>
          )}
        </div>
      )}
    </div>
  );
}
