import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { BrainwaveDisplay } from "@/components/BrainwaveDisplay";
import { JournalInput } from "@/components/JournalInput";
import { MoodAnalysis } from "@/components/MoodAnalysis";
import { StatsPanel } from "@/components/StatsPanel";

interface JournalEntry {
  id: string;
  text: string;
  timestamp: string;
  eegData: {
    delta: number;
    theta: number;
    alpha: number;
    beta: number;
    gamma: number;
    wordCount: number;
  };
  moodAnalysis: string;
  wordCount: number;
}

export default function Home() {
  const [currentEntry, setCurrentEntry] = useState<JournalEntry | null>(null);
  const [systemStatus, setSystemStatus] = useState("System Online - Production Ready");

  const { data: healthData } = useQuery({
    queryKey: ["/api/health"],
    refetchInterval: 300000, // 5 minutes
  }) as { data?: { services?: { openai?: string; email?: string } } };

  return (
    <div className="bg-space-gradient min-h-screen text-white font-space">
      <div className="container mx-auto max-w-7xl p-4 lg:p-8">
        
        {/* Header */}
        <header className="text-center mb-10 p-8 glassmorphism rounded-3xl">
          <h1 className="text-5xl lg:text-6xl font-bold text-cyber-cyan mb-4 text-glow animate-pulse-slow">
            🧠 EEG Journal Analyzer
          </h1>
          <p className="text-xl lg:text-2xl text-purple-300 mb-6">
            NASA-Level Brainwave Analysis & AI-Powered Insights
          </p>
          
          <div className="inline-flex items-center gap-2 bg-green-500/20 px-6 py-2 rounded-full text-green-400 border border-green-500/30">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span data-testid="system-status">{systemStatus}</span>
          </div>
          
          {/* Deployment Status Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
            <div className="glassmorphism rounded-2xl p-4">
              <div className="flex items-center gap-3 mb-2">
                <i className="fas fa-server text-cyber-cyan text-lg"></i>
                <h3 className="font-semibold text-cyber-cyan">Replit Deployment</h3>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span className="text-sm text-gray-300">Production Server Active</span>
              </div>
            </div>
            
            <div className="glassmorphism rounded-2xl p-4">
              <div className="flex items-center gap-3 mb-2">
                <i className="fas fa-database text-purple-400 text-lg"></i>
                <h3 className="font-semibold text-purple-400">API Services</h3>
              </div>
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${(healthData?.services as any)?.openai === 'configured' ? 'bg-green-400' : 'bg-yellow-400'}`}></div>
                <span className="text-sm text-gray-300">
                  {(healthData?.services as any)?.openai === 'configured' ? 'APIs Connected' : 'Environment Setup Required'}
                </span>
              </div>
            </div>
            
            <div className="glassmorphism rounded-2xl p-4">
              <div className="flex items-center gap-3 mb-2">
                <i className="fas fa-envelope text-yellow-400 text-lg"></i>
                <h3 className="font-semibold text-yellow-400">Notifications</h3>
              </div>
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${(healthData?.services as any)?.email === 'configured' ? 'bg-green-400' : 'bg-blue-400'}`}></div>
                <span className="text-sm text-gray-300">
                  {(healthData?.services as any)?.email === 'configured' ? 'Email Active' : 'Cron Jobs Configured'}
                </span>
              </div>
            </div>
          </div>
        </header>

        {/* Main Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 mb-8">
          <JournalInput 
            onAnalysisComplete={setCurrentEntry}
            onStatusChange={setSystemStatus}
          />
          <BrainwaveDisplay 
            eegData={currentEntry?.eegData}
          />
        </div>

        {/* Results Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          <MoodAnalysis 
            moodAnalysis={currentEntry?.moodAnalysis}
            entry={currentEntry}
          />
          <StatsPanel />
        </div>

        {/* Deployment Panel */}
        <div className="glassmorphism rounded-3xl p-8 mb-8">
          <div className="flex items-center gap-3 mb-6">
            <i className="fas fa-rocket text-green-400 text-xl"></i>
            <h3 className="text-xl font-bold text-green-400">Production Deployment Configuration</h3>
            <div className="ml-auto">
              <span className="text-xs px-3 py-1 bg-green-400/20 text-green-400 rounded-full border border-green-400/30">
                Replit Ready
              </span>
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Environment Variables */}
            <div className="space-y-4">
              <h4 className="font-semibold text-cyber-cyan mb-4 flex items-center gap-2">
                <i className="fas fa-key"></i>
                Environment Variables
              </h4>
              
              <div className="space-y-3">
                <div className="bg-yellow-400/10 border-l-4 border-yellow-400 rounded-r-xl p-4">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-yellow-400">OPENAI_API_KEY</span>
                    <span className="text-xs px-2 py-1 bg-yellow-400/20 rounded text-yellow-400">Required</span>
                  </div>
                  <p className="text-sm text-gray-400 mt-1">Set your OpenAI API key for mood analysis</p>
                </div>
                
                <div className="bg-blue-400/10 border-l-4 border-blue-400 rounded-r-xl p-4">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-blue-400">NOTION_INTEGRATION_SECRET</span>
                    <span className="text-xs px-2 py-1 bg-blue-400/20 rounded text-blue-400">Required</span>
                  </div>
                  <p className="text-sm text-gray-400 mt-1">Notion integration token for data storage</p>
                </div>
                
                <div className="bg-green-400/10 border-l-4 border-green-400 rounded-r-xl p-4">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-green-400">EMAIL_USER</span>
                    <span className="text-xs px-2 py-1 bg-green-400/20 rounded text-green-400">Optional</span>
                  </div>
                  <p className="text-sm text-gray-400 mt-1">Email address for daily reminders</p>
                </div>
              </div>
            </div>
            
            {/* Deployment Checklist */}
            <div className="space-y-4">
              <h4 className="font-semibold text-cyber-cyan mb-4 flex items-center gap-2">
                <i className="fas fa-tasks"></i>
                Deployment Checklist
              </h4>
              
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 bg-green-500/10 rounded-xl border border-green-500/30">
                  <i className="fas fa-check text-green-400"></i>
                  <span className="text-green-400">✓ Package.json configured</span>
                </div>
                
                <div className="flex items-center gap-3 p-3 bg-green-500/10 rounded-xl border border-green-500/30">
                  <i className="fas fa-check text-green-400"></i>
                  <span className="text-green-400">✓ Static files serving</span>
                </div>
                
                <div className={`flex items-center gap-3 p-3 rounded-xl border ${
                  (healthData?.services as any)?.openai === 'configured' 
                    ? 'bg-green-500/10 border-green-500/30' 
                    : 'bg-yellow-400/10 border-yellow-400/30'
                }`}>
                  <i className={`fas ${(healthData?.services as any)?.openai === 'configured' ? 'fa-check text-green-400' : 'fa-clock text-yellow-400'}`}></i>
                  <span className={(healthData?.services as any)?.openai === 'configured' ? 'text-green-400' : 'text-yellow-400'}>
                    {(healthData?.services as any)?.openai === 'configured' ? '✓ Environment variables setup' : '⏳ Environment variables setup'}
                  </span>
                </div>
                
                <div className="flex items-center gap-3 p-3 bg-green-500/10 rounded-xl border border-green-500/30">
                  <i className="fas fa-check text-green-400"></i>
                  <span className="text-green-400">✓ API integrations ready</span>
                </div>
                
                <div className={`flex items-center gap-3 p-3 rounded-xl border ${
                  (healthData?.services as any)?.email === 'configured' 
                    ? 'bg-green-500/10 border-green-500/30' 
                    : 'bg-gray-600/30 border-gray-600/50'
                }`}>
                  <i className={`fas ${(healthData?.services as any)?.email === 'configured' ? 'fa-check text-green-400' : 'fa-square text-gray-400'}`}></i>
                  <span className={(healthData?.services as any)?.email === 'configured' ? 'text-green-400' : 'text-gray-400'}>
                    {(healthData?.services as any)?.email === 'configured' ? '✓ Cron job validation' : '⬜ Cron job validation'}
                  </span>
                </div>
                
                <div className="flex items-center gap-3 p-3 bg-green-500/10 rounded-xl border border-green-500/30">
                  <i className="fas fa-check text-green-400"></i>
                  <span className="text-green-400">✓ CSV export testing</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Deployment Commands */}
          <div className="mt-8 p-6 bg-black/30 rounded-2xl">
            <h4 className="font-semibold text-cyber-cyan mb-4 flex items-center gap-2">
              <i className="fas fa-terminal"></i>
              Quick Deploy Commands
            </h4>
            
            <div className="space-y-3 font-mono text-sm">
              <div className="bg-gray-800/80 p-3 rounded-lg">
                <span className="text-green-400">$</span> <span className="text-gray-300">npm install</span>
              </div>
              <div className="bg-gray-800/80 p-3 rounded-lg">
                <span className="text-green-400">$</span> <span className="text-gray-300">npm run dev</span>
              </div>
              <div className="bg-gray-800/80 p-3 rounded-lg">
                <span className="text-blue-400">#</span> <span className="text-gray-300">Set environment variables in Replit Secrets</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer className="text-center py-8 glassmorphism rounded-2xl">
          <div className="flex items-center justify-center gap-6 mb-4">
            <div className="flex items-center gap-2 text-green-400">
              <i className="fas fa-server"></i>
              <span className="text-sm">Production Server</span>
            </div>
            <div className="flex items-center gap-2 text-cyber-cyan">
              <i className="fas fa-shield-alt"></i>
              <span className="text-sm">Secure Environment</span>
            </div>
            <div className="flex items-center gap-2 text-purple-400">
              <i className="fas fa-chart-line"></i>
              <span className="text-sm">Real-time Analytics</span>
            </div>
          </div>
          <p className="text-gray-400 text-sm">
            EEG Journal Analyzer © 2024 - Deployed on Replit with ❤️ and 🧠
          </p>
        </footer>
        
      </div>
    </div>
  );
}
